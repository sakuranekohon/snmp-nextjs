
export default function RmonTable(){
    return(
        <div>
            
        </div>
    )
}