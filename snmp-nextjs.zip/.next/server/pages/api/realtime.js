"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/realtime";
exports.ids = ["pages/api/realtime"];
exports.modules = {

/***/ "net-snmp":
/*!***************************!*\
  !*** external "net-snmp" ***!
  \***************************/
/***/ ((module) => {

module.exports = require("net-snmp");

/***/ }),

/***/ "next/dist/compiled/next-server/pages-api.runtime.dev.js":
/*!**************************************************************************!*\
  !*** external "next/dist/compiled/next-server/pages-api.runtime.dev.js" ***!
  \**************************************************************************/
/***/ ((module) => {

module.exports = require("next/dist/compiled/next-server/pages-api.runtime.dev.js");

/***/ }),

/***/ "(api)/./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES_API&page=%2Fapi%2Frealtime&preferredRegion=&absolutePagePath=.%2Fpages%5Capi%5Crealtime.js&middlewareConfigBase64=e30%3D!":
/*!**********************************************************************************************************************************************************************************************************************!*\
  !*** ./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES_API&page=%2Fapi%2Frealtime&preferredRegion=&absolutePagePath=.%2Fpages%5Capi%5Crealtime.js&middlewareConfigBase64=e30%3D! ***!
  \**********************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   config: () => (/* binding */ config),\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__),\n/* harmony export */   routeModule: () => (/* binding */ routeModule)\n/* harmony export */ });\n/* harmony import */ var next_dist_server_future_route_modules_pages_api_module_compiled__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next/dist/server/future/route-modules/pages-api/module.compiled */ \"(api)/./node_modules/next/dist/server/future/route-modules/pages-api/module.compiled.js\");\n/* harmony import */ var next_dist_server_future_route_modules_pages_api_module_compiled__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_pages_api_module_compiled__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! next/dist/server/future/route-kind */ \"(api)/./node_modules/next/dist/server/future/route-kind.js\");\n/* harmony import */ var next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/dist/build/templates/helpers */ \"(api)/./node_modules/next/dist/build/templates/helpers.js\");\n/* harmony import */ var _pages_api_realtime_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./pages\\api\\realtime.js */ \"(api)/./pages/api/realtime.js\");\n\n\n\n// Import the userland code.\n\n// Re-export the handler (should be the default export).\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ((0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_api_realtime_js__WEBPACK_IMPORTED_MODULE_3__, \"default\"));\n// Re-export config.\nconst config = (0,next_dist_build_templates_helpers__WEBPACK_IMPORTED_MODULE_2__.hoist)(_pages_api_realtime_js__WEBPACK_IMPORTED_MODULE_3__, \"config\");\n// Create and export the route module that will be consumed.\nconst routeModule = new next_dist_server_future_route_modules_pages_api_module_compiled__WEBPACK_IMPORTED_MODULE_0__.PagesAPIRouteModule({\n    definition: {\n        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__.RouteKind.PAGES_API,\n        page: \"/api/realtime\",\n        pathname: \"/api/realtime\",\n        // The following aren't used in production.\n        bundlePath: \"\",\n        filename: \"\"\n    },\n    userland: _pages_api_realtime_js__WEBPACK_IMPORTED_MODULE_3__\n});\n\n//# sourceMappingURL=pages-api.js.map//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9ub2RlX21vZHVsZXMvbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LXJvdXRlLWxvYWRlci9pbmRleC5qcz9raW5kPVBBR0VTX0FQSSZwYWdlPSUyRmFwaSUyRnJlYWx0aW1lJnByZWZlcnJlZFJlZ2lvbj0mYWJzb2x1dGVQYWdlUGF0aD0uJTJGcGFnZXMlNUNhcGklNUNyZWFsdGltZS5qcyZtaWRkbGV3YXJlQ29uZmlnQmFzZTY0PWUzMCUzRCEiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFBc0c7QUFDdkM7QUFDTDtBQUMxRDtBQUNzRDtBQUN0RDtBQUNBLGlFQUFlLHdFQUFLLENBQUMsbURBQVEsWUFBWSxFQUFDO0FBQzFDO0FBQ08sZUFBZSx3RUFBSyxDQUFDLG1EQUFRO0FBQ3BDO0FBQ08sd0JBQXdCLGdIQUFtQjtBQUNsRDtBQUNBLGNBQWMseUVBQVM7QUFDdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLEtBQUs7QUFDTCxZQUFZO0FBQ1osQ0FBQzs7QUFFRCIsInNvdXJjZXMiOlsid2VicGFjazovLy8/YzRlNyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBQYWdlc0FQSVJvdXRlTW9kdWxlIH0gZnJvbSBcIm5leHQvZGlzdC9zZXJ2ZXIvZnV0dXJlL3JvdXRlLW1vZHVsZXMvcGFnZXMtYXBpL21vZHVsZS5jb21waWxlZFwiO1xuaW1wb3J0IHsgUm91dGVLaW5kIH0gZnJvbSBcIm5leHQvZGlzdC9zZXJ2ZXIvZnV0dXJlL3JvdXRlLWtpbmRcIjtcbmltcG9ydCB7IGhvaXN0IH0gZnJvbSBcIm5leHQvZGlzdC9idWlsZC90ZW1wbGF0ZXMvaGVscGVyc1wiO1xuLy8gSW1wb3J0IHRoZSB1c2VybGFuZCBjb2RlLlxuaW1wb3J0ICogYXMgdXNlcmxhbmQgZnJvbSBcIi4vcGFnZXNcXFxcYXBpXFxcXHJlYWx0aW1lLmpzXCI7XG4vLyBSZS1leHBvcnQgdGhlIGhhbmRsZXIgKHNob3VsZCBiZSB0aGUgZGVmYXVsdCBleHBvcnQpLlxuZXhwb3J0IGRlZmF1bHQgaG9pc3QodXNlcmxhbmQsIFwiZGVmYXVsdFwiKTtcbi8vIFJlLWV4cG9ydCBjb25maWcuXG5leHBvcnQgY29uc3QgY29uZmlnID0gaG9pc3QodXNlcmxhbmQsIFwiY29uZmlnXCIpO1xuLy8gQ3JlYXRlIGFuZCBleHBvcnQgdGhlIHJvdXRlIG1vZHVsZSB0aGF0IHdpbGwgYmUgY29uc3VtZWQuXG5leHBvcnQgY29uc3Qgcm91dGVNb2R1bGUgPSBuZXcgUGFnZXNBUElSb3V0ZU1vZHVsZSh7XG4gICAgZGVmaW5pdGlvbjoge1xuICAgICAgICBraW5kOiBSb3V0ZUtpbmQuUEFHRVNfQVBJLFxuICAgICAgICBwYWdlOiBcIi9hcGkvcmVhbHRpbWVcIixcbiAgICAgICAgcGF0aG5hbWU6IFwiL2FwaS9yZWFsdGltZVwiLFxuICAgICAgICAvLyBUaGUgZm9sbG93aW5nIGFyZW4ndCB1c2VkIGluIHByb2R1Y3Rpb24uXG4gICAgICAgIGJ1bmRsZVBhdGg6IFwiXCIsXG4gICAgICAgIGZpbGVuYW1lOiBcIlwiXG4gICAgfSxcbiAgICB1c2VybGFuZFxufSk7XG5cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXBhZ2VzLWFwaS5qcy5tYXAiXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(api)/./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES_API&page=%2Fapi%2Frealtime&preferredRegion=&absolutePagePath=.%2Fpages%5Capi%5Crealtime.js&middlewareConfigBase64=e30%3D!\n");

/***/ }),

/***/ "(api)/./pages/api/realtime.js":
/*!*******************************!*\
  !*** ./pages/api/realtime.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ handler)\n/* harmony export */ });\n/* harmony import */ var net_snmp__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! net-snmp */ \"net-snmp\");\n/* harmony import */ var net_snmp__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(net_snmp__WEBPACK_IMPORTED_MODULE_0__);\n\nasync function handler(req, res) {\n    if (req.method === \"GET\") {\n        const { vlan } = req.query;\n        const targetIP = \"192.168.1.1\";\n        const community = \"public\";\n        const session = net_snmp__WEBPACK_IMPORTED_MODULE_0___default().createSession(targetIP, community);\n        const oids = [\n            `1.3.6.1.2.1.2.2.1.10.${vlan}`,\n            `1.3.6.1.2.1.2.2.1.16.${vlan}`\n        ];\n        session.get(oids, (error, varbinds)=>{\n            if (error) {\n                console.error(\"SNMP request failed:\", error);\n                res.status(500).json({\n                    error: \"SNMP request failed\"\n                });\n            } else {\n                const inputTraffic = varbinds[0].value || 0;\n                const outputTraffic = varbinds[1].value || 0;\n                res.status(200).json({\n                    inputTraffic,\n                    outputTraffic\n                });\n            }\n            session.close();\n        });\n    } else {\n        res.status(405).json({\n            error: \"Method Not Allowed\"\n        });\n    }\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvcmVhbHRpbWUuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQTRCO0FBRWIsZUFBZUMsUUFBUUMsR0FBRyxFQUFFQyxHQUFHO0lBQzVDLElBQUlELElBQUlFLE1BQU0sS0FBSyxPQUFPO1FBQ3hCLE1BQU0sRUFBRUMsSUFBSSxFQUFFLEdBQUdILElBQUlJLEtBQUs7UUFDMUIsTUFBTUMsV0FBVztRQUNqQixNQUFNQyxZQUFZO1FBRWxCLE1BQU1DLFVBQVVULDZEQUFrQixDQUFDTyxVQUFVQztRQUU3QyxNQUFNRyxPQUFPO1lBQ1gsQ0FBQyxxQkFBcUIsRUFBRU4sS0FBSyxDQUFDO1lBQzlCLENBQUMscUJBQXFCLEVBQUVBLEtBQUssQ0FBQztTQUMvQjtRQUVESSxRQUFRRyxHQUFHLENBQUNELE1BQU0sQ0FBQ0UsT0FBT0M7WUFDeEIsSUFBSUQsT0FBTztnQkFDVEUsUUFBUUYsS0FBSyxDQUFDLHdCQUF3QkE7Z0JBQ3RDVixJQUFJYSxNQUFNLENBQUMsS0FBS0MsSUFBSSxDQUFDO29CQUFFSixPQUFPO2dCQUFzQjtZQUN0RCxPQUFPO2dCQUNMLE1BQU1LLGVBQWVKLFFBQVEsQ0FBQyxFQUFFLENBQUNLLEtBQUssSUFBSTtnQkFDMUMsTUFBTUMsZ0JBQWdCTixRQUFRLENBQUMsRUFBRSxDQUFDSyxLQUFLLElBQUk7Z0JBQzNDaEIsSUFBSWEsTUFBTSxDQUFDLEtBQUtDLElBQUksQ0FBQztvQkFBRUM7b0JBQWNFO2dCQUFjO1lBQ3JEO1lBQ0FYLFFBQVFZLEtBQUs7UUFDZjtJQUNGLE9BQU87UUFDTGxCLElBQUlhLE1BQU0sQ0FBQyxLQUFLQyxJQUFJLENBQUM7WUFBRUosT0FBTztRQUFxQjtJQUNyRDtBQUNGIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vLy4vcGFnZXMvYXBpL3JlYWx0aW1lLmpzPzA0ODMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHNubXAgZnJvbSAnbmV0LXNubXAnO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgYXN5bmMgZnVuY3Rpb24gaGFuZGxlcihyZXEsIHJlcykge1xyXG4gIGlmIChyZXEubWV0aG9kID09PSAnR0VUJykge1xyXG4gICAgY29uc3QgeyB2bGFuIH0gPSByZXEucXVlcnk7XHJcbiAgICBjb25zdCB0YXJnZXRJUCA9ICcxOTIuMTY4LjEuMSc7XHJcbiAgICBjb25zdCBjb21tdW5pdHkgPSAncHVibGljJztcclxuXHJcbiAgICBjb25zdCBzZXNzaW9uID0gc25tcC5jcmVhdGVTZXNzaW9uKHRhcmdldElQLCBjb21tdW5pdHkpO1xyXG5cclxuICAgIGNvbnN0IG9pZHMgPSBbXHJcbiAgICAgIGAxLjMuNi4xLjIuMS4yLjIuMS4xMC4ke3ZsYW59YCxcclxuICAgICAgYDEuMy42LjEuMi4xLjIuMi4xLjE2LiR7dmxhbn1gLFxyXG4gICAgXTtcclxuXHJcbiAgICBzZXNzaW9uLmdldChvaWRzLCAoZXJyb3IsIHZhcmJpbmRzKSA9PiB7XHJcbiAgICAgIGlmIChlcnJvcikge1xyXG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ1NOTVAgcmVxdWVzdCBmYWlsZWQ6JywgZXJyb3IpO1xyXG4gICAgICAgIHJlcy5zdGF0dXMoNTAwKS5qc29uKHsgZXJyb3I6ICdTTk1QIHJlcXVlc3QgZmFpbGVkJyB9KTtcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBjb25zdCBpbnB1dFRyYWZmaWMgPSB2YXJiaW5kc1swXS52YWx1ZSB8fCAwO1xyXG4gICAgICAgIGNvbnN0IG91dHB1dFRyYWZmaWMgPSB2YXJiaW5kc1sxXS52YWx1ZSB8fCAwO1xyXG4gICAgICAgIHJlcy5zdGF0dXMoMjAwKS5qc29uKHsgaW5wdXRUcmFmZmljLCBvdXRwdXRUcmFmZmljIH0pO1xyXG4gICAgICB9XHJcbiAgICAgIHNlc3Npb24uY2xvc2UoKTtcclxuICAgIH0pO1xyXG4gIH0gZWxzZSB7XHJcbiAgICByZXMuc3RhdHVzKDQwNSkuanNvbih7IGVycm9yOiAnTWV0aG9kIE5vdCBBbGxvd2VkJyB9KTtcclxuICB9XHJcbn1cclxuIl0sIm5hbWVzIjpbInNubXAiLCJoYW5kbGVyIiwicmVxIiwicmVzIiwibWV0aG9kIiwidmxhbiIsInF1ZXJ5IiwidGFyZ2V0SVAiLCJjb21tdW5pdHkiLCJzZXNzaW9uIiwiY3JlYXRlU2Vzc2lvbiIsIm9pZHMiLCJnZXQiLCJlcnJvciIsInZhcmJpbmRzIiwiY29uc29sZSIsInN0YXR1cyIsImpzb24iLCJpbnB1dFRyYWZmaWMiLCJ2YWx1ZSIsIm91dHB1dFRyYWZmaWMiLCJjbG9zZSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(api)/./pages/api/realtime.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, ["vendor-chunks/next"], () => (__webpack_exec__("(api)/./node_modules/next/dist/build/webpack/loaders/next-route-loader/index.js?kind=PAGES_API&page=%2Fapi%2Frealtime&preferredRegion=&absolutePagePath=.%2Fpages%5Capi%5Crealtime.js&middlewareConfigBase64=e30%3D!")));
module.exports = __webpack_exports__;

})();