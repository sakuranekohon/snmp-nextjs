# 利用Node.js獲取網路管理設備資訊
使用Next.js框架來達成前後端分離  
暫且疑惑不知道為何不能只使用React.js來寫

## Using Step
使用前請先安裝Nodejs  
Step1: Open project using IDE or Editor  
Step2: Terminal enter "npm install"
Step3: Terminal enter "npm run dev"  
Step4: Web URL input localhost:3000  
Step5: Click create button  
Step6: Textbox input manage device IP and SNMP Objec ID  
Step7: Click searcj button  

finish then Output result  

## 資料夾說明
component => 放置自己所寫的元件  
pages => 放置頁面以及api資料夾(後端程式位置)  
public => 放置圖片、腳本(自己的函示庫)、icon  
styles => 放置css  

##  所使用的SNMP套件
Link:[net-snmp](https://www.npmjs.com/package/net-snmp)
